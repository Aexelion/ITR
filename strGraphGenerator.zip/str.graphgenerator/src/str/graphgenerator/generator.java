package str.graphgenerator;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class generator {

	public static void main(String[] args) throws IOException {
		//EXTRACTION DES DONNEES
		List<String> WCET = extractWCETFromXml("TP2-res.xml");
		List<String> Names = extractNamesFromXml("TP2-res.xml");


		//lesinfos : ce qui a �t� extrait du document XML
		HashMap<String, Integer> lesinfos =  combineLesListe(Names, WCET);
		//user : ce qui a �t� donn� par l'utilisateur (nom et temps d'execution des taches
		LinkedHashMap<String, Integer> user = new LinkedHashMap<String,Integer>();
		user = infoUser("user.txt");
		//le PPCM des info donn�es par l'user
		int ppcm = PPCMCALCULATOR(user);

		/*
		System.out.println(lesinfos.toString());
		System.out.println(user);
		System.out.println(PPCMCALCULATOR(user));
		System.out.println(priorityCalculator(lesinfos,user));
		 */

		//R�cup�ration de l'ordonnancement
		int[] ordon = new int[ppcm];
		int prio = 1;
		for(String s : user.keySet()) {
			//System.out.println(s + " " + prio);
			calculOrdonnencement(ordon, prio, s, lesinfos, user);
			prio++;
		}

		/*
		for(int par = 0; par<ordon.length;par++) {
			System.out.println(ordon[par]);
		}
		 */


		// DESSINAGE DU DESSIN DESSIN�
		try{
			FileWriter fw = new FileWriter("graphe.svg", false);	// creation du nouveau fichier
			BufferedWriter fichier = new BufferedWriter(fw);
			int ECART = 50;
			int LONGEUR = ppcm; // chaque ligne fait la taille de l'hyperperiode, on a donc 1px = 1ms

			// balises de debut de documents
			fichier.write("<!DOCTYPE html>");fichier.newLine();
			fichier.write("<html>");fichier.newLine();
			fichier.write("<body>");fichier.newLine();
			fichier.write("<svg height=\"1210\" width=\"1500\">");fichier.newLine();fichier.newLine();
			// LA LIGNE VERTICALE
			fichier.write("<line x1=\"0\" y1=\"0\" x2=\"0\" y2=\""+ ECART*user.size() + "\" style=\"stroke:rgb(0,0,0);stroke-width:2\" /> ");fichier.newLine();

			//LES LIGNES HORIZONTALE (autant que de taches donn�e par l'user)
			for(int nbhor = 1; nbhor<user.size()+1; nbhor++) {
				fichier.write("<line x1=\"0\" y1=\""+ECART*nbhor+ "\" x2=\""+LONGEUR+"\" y2=\""+ECART*nbhor+ "\" style=\"stroke:rgb(0,0,0);stroke-width:2\" />");fichier.newLine();	
			}
			// ajout des noms de taches en bout de ligne
			int txtec = 1;
			for(String s : user.keySet()) {
				fichier.write("<text font-family=\"Verdana\" x=\""+(LONGEUR+20)+"\" y=\""+ECART*txtec+ "\">"+s+"</text>");fichier.newLine();
				txtec++;
			}

			//affichage des taches sur le graphe
			List<String> toDraw = dessinageOrdon(ordon);
			//System.out.println(toDraw);
			for(String taches : toDraw) {
				fichier.write(taches);
				fichier.newLine();
			}






			//CLOSING
			fichier.newLine();
			fichier.write("</svg>");fichier.newLine();
			fichier.write("</body>");fichier.newLine();
			fichier.write("</html>");fichier.newLine();
			fichier.close();
		} catch (Exception e) { e.printStackTrace();}

		System.out.println("TRAVAILLE TERMIN�!");



	}


	/**
	 * Extrait de la string du XML la valeur du wcet.
	 * @param wcet : de la forme: <ATTR type="integer" name="WCET" value="XXX" />
	 * @return le XXX de la string (= la value de Wcet)
	 */
	public static String justeValue(String wcet) {
		String rep = wcet.substring(40); // le debut de value est toujours el 40�me char
		char b = '0';
		int i = 0;
		while(b!='"') {
			b=rep.charAt(i);
			i++;
		}
		return rep.substring(0, i-1);
	}

	/**
	 * Fonction qui cr�e la liste des WCET a partir du fichier xml g�n�r� par Heptane.
	 * cf huit.re/ITR "Et la theorie dans tout �a?"
	 * @param XMLNAME
	 * @return La liste des WCET du fichier XMLNAME
	 * @throws IOException
	 */
	public static List<String> extractWCETFromXml(String XMLNAME) throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader(XMLNAME));
		String line = reader.readLine();
		List<String> lines = new ArrayList<String>();
		while (line != null) {
			if(line.contains("name=\"WCET\"")) {
				lines.add(justeValue(line));
			}
			line = reader.readLine();
		}
		reader.close();
		return lines;
	}


	/**
	 * sous fonction pour extraire le nom seul de la string de la string 
	 * @param name
	 * @return
	 */
	public static String justeName(String name) {
		String rep = name.substring(18); // avance de 18 char pour gagner du temps
		char b = '0';
		int start = 0;
		int end = 0;

		while(b!='"') {
			b=rep.charAt(start);
			start++;
		}
		b = '0';
		while(b!='"') {
			b=rep.charAt(start+end);
			end++;
		}
		return rep.substring(start, start+end-1);
	}

	/**
	 * extrait les noms du XML gener� par Heptane
	 * @param XMLNAME
	 * @return la ligne avec le name
	 * @throws IOException
	 */
	public static List<String> extractNamesFromXml(String XMLNAME) throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader(XMLNAME));
		String line = reader.readLine();
		List<String> lines = new ArrayList<String>();
		while (line != null) {
			if(line.contains("name=\"") && line.contains("startnode=\"")) {
				lines.add(justeName(line));
			}
			line = reader.readLine();
		}
		reader.close();
		return lines;
	}


	/**
	 * Combine les listes de noms et les listes de WCET pour faire la hashmap final.
	 * Key : nom tache, Valeur : WCET
	 * @param lesname
	 * @param lesint
	 * @return
	 */
	public static HashMap<String, Integer> combineLesListe (List<String> lesname, List<String> lesint){
		HashMap<String, Integer> reponse = new HashMap<String, Integer>();
		for(int i = 0; i<lesname.size(); i++) {
			reponse.put(lesname.get(i), Integer.parseInt(lesint.get(i)));
		}	
		return reponse;
	}
	/**
	 *  la hashmap key: nom tache , valeur: tps d'execution. 
	 * @param Name : le nom du fichier utilisateur. 1 ligne pour le nom, 1 ligne pour la dur�e (en ms)
	 * @return
	 * @throws IOException
	 */
	public static LinkedHashMap<String, Integer> infoUser(String Name) throws IOException{
		LinkedHashMap<String, Integer> reponse = new LinkedHashMap<String, Integer>();

		BufferedReader reader = new BufferedReader(new FileReader(Name));
		String line = reader.readLine();
		while (line != null) {
			reponse.put(line, Integer.parseInt(reader.readLine()));	
			line = reader.readLine();
		}
		reader.close();


		return reponse;
	}


	/**
	 * PPCM de nb1 et nb2
	 * @param Nb1
	 * @param Nb2
	 * @return
	 */
	public static int Calcule_PPCM (int Nb1, int Nb2) {
		int Produit, Reste, PPCM;

		Produit = Nb1*Nb2;
		Reste   = Nb1%Nb2;
		while(Reste != 0){
			Nb1 = Nb2;
			Nb2 = Reste;
			Reste = Nb1%Nb2;
		}
		PPCM = Produit/Nb2;
		//System.out.println("PGCD = " + Nb2 + " PPCM = " + PPCM);
		return PPCM;		
	} 
	/**
	 * rend le ppcm de la liste des taches donn�es par l'utilisateur
	 * @param l : la hasmap des info user;
	 * @return le ppcm de cette liste
	 */
	public static int PPCMCALCULATOR(LinkedHashMap<String, Integer> l) {
		int[] leschiffres = new int[l.size()];
		int taille = 0;
		int res = 1;
		for(int i : l.values()) {
			leschiffres[taille] = i;
			taille++;
		}

		for(int b = 0; b<leschiffres.length; b++) {
			res = Calcule_PPCM(res,leschiffres[b]);
		}

		return res;
	}
	/**
	 * rend la table contenant la valeur WCET/TempsExecution, qui permet de definir l'ordre des priorit� des taches
	 * @param WCET la map des WCET associ� aux taches
	 * @param USER les taches avec leur dur�e d'exectuion fournis par l'utilisateur;
	 * @return
	 */
	public static HashMap<String, Double> priorityCalculator(HashMap<String, Integer> WCET, LinkedHashMap<String, Integer> USER ) {
		int cpt = 0;
		HashMap<String, Double> resultat = new HashMap<String, Double>();
		double[] res = new double[USER.size()];
		for(String u : USER.keySet()) {	// r�cup�re les WCET/Periode
			res[cpt] = (double)((WCET.get(u+"_function"))/48000)/USER.get(u);
			resultat.put(u, (double) ((WCET.get(u+"_function"))/48000)/USER.get(u));
			cpt++;
		}
		double probleme = 0;
		for(int parse = 0; parse<res.length;parse++) {
			probleme += res[parse];
		}
		if(probleme>1) {System.out.println("ALERTE: PIRE CAS D'EXECUTION TROP LONG PAR RAPPORT A LA PERIODE");}

		return resultat;


	}


	/**
	 * rend la table contenant la valeur WCET/TempsExecution, qui permet de definir l'ordre des priorit� des taches
	 * @param WCET la map des WCET associ� aux taches
	 * @param USER les taches avec leur dur�e d'exectuion fournis par l'utilisateur;
	 * @return
	 */
	public static boolean conditionNecessaire(HashMap<String, Integer> WCET, LinkedHashMap<String, Integer> USER ) {
		int cpt = 0;
		double[] res = new double[USER.size()];
		for(String u : USER.keySet()) {	// r�cup�re les WCET/Periode
			//le processeur du NXT est de 48MHz (48.10^6 , le temps user est en ms(1.10^-3)
			res[cpt] = (double)((WCET.get(u+"_function"))/48000)/USER.get(u);
			cpt++;
		}
		double probleme = 0;
		for(int parse = 0; parse<res.length;parse++) {
			probleme += res[parse];
		}
		//if(probleme>1) {System.out.println("ALERTE: PIRE CAS D'EXECUTION TROP LONG PAR RAPPORT A LA PERIODE");}
		return probleme>1;


	}
	/**
	 * Ajoute la fonction donn� en param�tre dans l'ordonnancement par rapport a sa priorit�
	 * Si jamais l'ordonnancement est deja complet et que la tache a une priorit� moindre, rien ne va se passer
	 * cette fonction est pr�vu pour etre appaller successivement sur les taches en priorit� d�croissante 
	 * La valeur 0 represente un espace vide, puis les priorit� par ordre croissant (1>2>3 ...)
	 * @param ordon le tableau d'ordonnacement de taille ppcm.
	 * @param prio	priorit� de la tache a ordonnanc�
	 * @param TaskName	nom de la tache
	 * @param WCET	la hasmap de WCET comme partout dans ce programme
	 * @param USER	la LinkedHashMap des infos user
	 * @return le nouvelle ordonnancement (pas n�c�ssaire, peut etre mis a void si besoin)
	 */
	public static int[] calculOrdonnencement(int ordon[], int prio, String TaskName, HashMap<String, Integer> WCET, LinkedHashMap<String, Integer> USER ) {
		int periode = USER.get(TaskName);	// la periode en MS
		int exectime = (WCET.get(TaskName+"_function"))/48000;	// tps d'exec en millisecondes
		if(exectime==0) {exectime=1;}							// si <1ms , alors on le mets a 1ms par defaut

		boolean cycleOk = false;	 // a t'on fini d'executer la tache sur le cycle courant
		int execleft = exectime;	// tps d'execution restant
		int retard = 0;				// cycle de retard si execution non termin�

		//System.out.println(prio + ". Periode:" + periode + " execTime: " + exectime);
		for(int i = 0;i<ordon.length;i++ ) {	
			if((i%periode)==0 && i!=0) {
				cycleOk = false;
				if(execleft!=0) {retard++;}
				else {execleft = exectime;}
			}
			if(execleft!=0) {
				if(ordon[i]>prio || ordon[i]==0) {// il n'y a pas de tache plus prioritaire a ce moment
					if(!cycleOk) { // si le cycle n'est pas fini
						ordon[i]=prio;
						execleft--;

						if(execleft==0 && retard!=0) {	// si la tache a du retard sur des cycles pr�c�dents
							retard--;
							execleft = exectime;
						}
						else if(execleft==0) {cycleOk = true;}


					}
				}
			}

		}

		return ordon;
	}
	/**
	 * renvoi la liste des string a imprim� pour afficher l'ordonnancement sur le graph
	 * @param ordon l'ordonnancement de taille ppcm
	 * @return
	 */
	public static List<String> dessinageOrdon(int[] ordon){
		List<String> resultat = new ArrayList<String>();
		int previous = 0;
		int row = 0;

		for(int par=0;par<ordon.length;par++) {
			if(ordon[par]!=0) {
				if(ordon[par]==previous) {
					row++;
				}
				else {
					if((row)!=0) {
						resultat.add("<rect x=\""+ (par-row) +"\" y=\""+ ((previous*50)-20) +"\" width=\"" +row+ "\" height=\"20\" style=\"fill:rgb(0,0,255);stroke-width:2;stroke:rgb(0,0,0)\" />");
					}
					row = 1;
					previous = ordon[par];
				}
			}
			else {
				if(previous!=0) {
					if((row)!=0) {	
						resultat.add("<rect x=\""+ (par-row) +"\" y=\""+ ((previous*50)-20) +"\" width=\"" +row+ "\" height=\"20\" style=\"fill:rgb(0,0,255);stroke-width:2;stroke:rgb(0,0,0)\" />");
					}
				}
				previous = 0;
				row = 0;
			}
		}
		return resultat;

	}



}
