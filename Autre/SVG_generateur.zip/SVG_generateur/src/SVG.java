//https://www.w3schools.com/graphics/svg_examples.asp

public class SVG {
	String fichier;
	public void creation(){
		for eachlines dans fichier {
			create Nom(gauche);
			create ligne;//Graduation comprises
			create periodes;
		}
	}
	//RM
	public void ordonnancement(String type){
		
	}
}
